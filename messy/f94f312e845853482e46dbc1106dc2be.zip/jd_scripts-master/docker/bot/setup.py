# -*- coding: utf-8 -*-
# @Author    : iouAkira(lof)
# @mail      : e.akimoto.akira@gmail.com
# @CreateTime: 2020-11-02
# @UpdateTime: 2021-03-21

from setuptools import setup

setup(
    name='jd-scripts-bot',
    version='0.2',
    scripts=['jd_bot', ],
)
